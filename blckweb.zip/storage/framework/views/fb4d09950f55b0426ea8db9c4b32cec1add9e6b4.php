<div class="space-y-8 mt-4">
    <!-- Input Types -->
    <div>
        <div class="">
            <div>
                <!-- Start -->
                <div class="flex"> <?php echo Form::label('name', 'Título de la categoría', ['class' => 'block text-sm font-medium mb-1']); ?><span class="text-rose-500">*</span></div>
                <?php echo Form::text('name', null, [
                    'class' => 'form-input w-full',
                    'placeholder' => 'Ingresa el nombre de la categoría',
                ]); ?>

                <!-- End -->

                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-red-700"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mt-3">
                <!-- Start -->
                <div class="flex"> <?php echo Form::label('slug', 'Slug de la categoría', ['class' => 'block text-sm font-medium mb-1']); ?><span class="text-rose-500">*</span></div>
                <?php echo Form::text('slug', null, [
                    'class' => 'form-input w-full',
                    'placeholder' => 'Ingresa el slug de la categoría',
                    'readonly' => true,
                ]); ?>

                <!-- End -->
                <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-red-700"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\blckweb\resources\views\admin\categories\form.blade.php ENDPATH**/ ?>