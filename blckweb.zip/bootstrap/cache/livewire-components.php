<?php return array (
  'category-list' => 'App\\Http\\Livewire\\CategoryList',
  'comment-post' => 'App\\Http\\Livewire\\CommentPost',
  'home-post-list' => 'App\\Http\\Livewire\\HomePostList',
  'list-post' => 'App\\Http\\Livewire\\ListPost',
  'role-list' => 'App\\Http\\Livewire\\RoleList',
  'tag-list' => 'App\\Http\\Livewire\\TagList',
  'user-list' => 'App\\Http\\Livewire\\UserList',
);