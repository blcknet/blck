<x-app-layout>
    @livewire('category-list')
</x-app-layout>
