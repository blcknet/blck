<x-app-layout>
    @livewire('tag-list')
</x-app-layout>
