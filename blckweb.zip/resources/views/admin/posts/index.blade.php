<x-app-layout>
    @livewire('list-post')
</x-app-layout>
