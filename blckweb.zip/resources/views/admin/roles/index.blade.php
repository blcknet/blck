<x-app-layout>
    @livewire('role-list')
</x-app-layout>
