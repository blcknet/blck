<x-app-layout>
    @livewire('user-list')
</x-app-layout>
